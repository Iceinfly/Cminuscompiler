#include <sstream>
#pragma once
//Symbol table header
#include <string.h>
#include <string>
using namespace std;


string cBS(char* c){
    char* cstr = c;
    std::string str(cstr);
    return cstr;
}